package com.phototopdf;

import android.content.Intent;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.*;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class ConvertActivity extends AppCompatActivity {

    private LinearProgressIndicator progressBar;
    private TextView tvStatus;
    private TextView tvProgress;
    private MaterialButton btnShare, btnOpenFile, btnBack;
    private LinearLayout layoutSuccess, layoutConverting;

    private List<Uri> photos;
    private int quality;
    private String pageSize;
    private boolean scannerMode;
    private File outputFile;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private static final Map<String, int[]> PAGE_SIZES = new HashMap<>();
    static {
        PAGE_SIZES.put("A4",     new int[]{595, 842});
        PAGE_SIZES.put("A3",     new int[]{842, 1190});
        PAGE_SIZES.put("Letter", new int[]{612, 792});
        PAGE_SIZES.put("A5",     new int[]{420, 595});
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_convert);
        initViews();

        Intent intent = getIntent();
        photos = intent.getParcelableArrayListExtra("photos");
        quality = intent.getIntExtra("quality", 85);
        pageSize = intent.getStringExtra("pageSize");
        scannerMode = intent.getBooleanExtra("scannerMode", false);
        if (pageSize == null) pageSize = "A4";

        startConversion();
    }

    private void initViews() {
        progressBar = findViewById(R.id.progressBar);
        tvStatus = findViewById(R.id.tvStatus);
        tvProgress = findViewById(R.id.tvProgress);
        btnShare = findViewById(R.id.btnShare);
        btnOpenFile = findViewById(R.id.btnOpenFile);
        btnBack = findViewById(R.id.btnBack);
        layoutSuccess = findViewById(R.id.layoutSuccess);
        layoutConverting = findViewById(R.id.layoutConverting);

        btnShare.setOnClickListener(v -> sharePdf());
        btnOpenFile.setOnClickListener(v -> openPdf());
        btnBack.setOnClickListener(v -> finish());
    }

    private void startConversion() {
        executor.execute(() -> {
            try {
                String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
                String fileName = "PhotoToPDF_" + timestamp + ".pdf";

                File outputDir = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "PhotoToPDF");
                if (!outputDir.exists()) outputDir.mkdirs();
                outputFile = new File(outputDir, fileName);

                int[] dims = PAGE_SIZES.containsKey(pageSize) ? PAGE_SIZES.get(pageSize) : PAGE_SIZES.get("A4");
                int pageW = dims[0];
                int pageH = dims[1];

                PdfDocument pdfDocument = new PdfDocument();
                Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
                int total = photos.size();

                for (int i = 0; i < total; i++) {
                    final int idx = i;
                    runOnUiThread(() -> {
                        tvStatus.setText("İşleniyor: " + (idx + 1) + "/" + total +
                            (scannerMode ? " (Tarayıcı modu)" : ""));
                        tvProgress.setText((int)((idx / (float) total) * 100) + "%");
                        progressBar.setProgress((int)((idx / (float) total) * 100));
                    });

                    Uri photoUri = photos.get(i);

                    // Decode with downsampling to save memory
                    BitmapFactory.Options opts = new BitmapFactory.Options();
                    opts.inSampleSize = calculateInSampleSize(photoUri, pageW * 2, pageH * 2);
                    InputStream is = getContentResolver().openInputStream(photoUri);
                    Bitmap bmp = BitmapFactory.decodeStream(is, null, opts);
                    if (is != null) is.close();
                    if (bmp == null) continue;

                    // Apply scanner effect if enabled
                    if (scannerMode) {
                        Bitmap scanned = DocumentProcessor.applyScanner(bmp);
                        bmp.recycle();
                        bmp = scanned;
                    }

                    // Create PDF page
                    PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageW, pageH, i + 1).create();
                    PdfDocument.Page page = pdfDocument.startPage(pageInfo);
                    Canvas canvas = page.getCanvas();
                    canvas.drawRGB(255, 255, 255);

                    float bmpW = bmp.getWidth();
                    float bmpH = bmp.getHeight();
                    float scale = Math.min(pageW / bmpW, pageH / bmpH);
                    float drawW = bmpW * scale;
                    float drawH = bmpH * scale;
                    float left = (pageW - drawW) / 2f;
                    float top = (pageH - drawH) / 2f;

                    canvas.drawBitmap(bmp, null, new RectF(left, top, left + drawW, top + drawH), paint);
                    pdfDocument.finishPage(page);
                    bmp.recycle();
                }

                FileOutputStream fos = new FileOutputStream(outputFile);
                pdfDocument.writeTo(fos);
                fos.close();
                pdfDocument.close();

                runOnUiThread(this::showSuccess);

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> tvStatus.setText("Hata: " + e.getMessage()));
            }
        });
    }

    private int calculateInSampleSize(Uri uri, int reqW, int reqH) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(is, null, opts);
            if (is != null) is.close();
            int inSampleSize = 1;
            while ((opts.outHeight / inSampleSize) > reqH || (opts.outWidth / inSampleSize) > reqW) {
                inSampleSize *= 2;
            }
            return inSampleSize;
        } catch (Exception e) { return 1; }
    }

    private void showSuccess() {
        layoutConverting.setVisibility(View.GONE);
        layoutSuccess.setVisibility(View.VISIBLE);
        progressBar.setProgress(100);
        Toast.makeText(this, "PDF hazır! 🎉", Toast.LENGTH_LONG).show();
    }

    private Uri getPdfUri() {
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", outputFile);
    }

    private void sharePdf() {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("application/pdf");
            i.putExtra(Intent.EXTRA_STREAM, getPdfUri());
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "PDF'yi Paylaş"));
        } catch (Exception e) {
            Toast.makeText(this, "Paylaşma hatası", Toast.LENGTH_SHORT).show();
        }
    }

    private void openPdf() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(getPdfUri(), "application/pdf");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "PDF görüntüleyici bulunamadı", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
