package com.phototopdf;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.activity.result.*;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.*;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.slider.Slider;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.*;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private PhotoAdapter photoAdapter;
    private final List<Uri> selectedPhotos = new ArrayList<>();
    private ExtendedFloatingActionButton fabConvert;
    private TextView tvPhotoCount;
    private View tvEmptyState;
    private View scrollView;

    // PDF Settings
    private int pdfQuality = 85;
    private String pageSize = "A4";
    private boolean scannerMode = false; // siyah-beyaz tarayıcı modu

    private final ActivityResultLauncher<String[]> permissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
            boolean granted = !result.containsValue(false);
            if (granted) openPhotoPicker();
            else Toast.makeText(this, "İzin gerekli!", Toast.LENGTH_LONG).show();
        });

    private final ActivityResultLauncher<Intent> photoPickerLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                Intent data = result.getData();
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    for (int i = 0; i < count; i++) {
                        Uri uri = data.getClipData().getItemAt(i).getUri();
                        if (!selectedPhotos.contains(uri)) selectedPhotos.add(uri);
                    }
                } else if (data.getData() != null) {
                    Uri uri = data.getData();
                    if (!selectedPhotos.contains(uri)) selectedPhotos.add(uri);
                }
                updateUI();
            }
        });

    private final ActivityResultLauncher<Intent> cameraLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                Uri uri = result.getData().getData();
                if (uri != null && !selectedPhotos.contains(uri)) {
                    selectedPhotos.add(uri);
                    updateUI();
                }
            }
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        setupRecyclerView();
    }

    private void initViews() {
        recyclerView = findViewById(R.id.recyclerView);
        fabConvert = findViewById(R.id.fabConvert);
        tvPhotoCount = findViewById(R.id.tvPhotoCount);
        tvEmptyState = findViewById(R.id.tvEmptyState);
        scrollView = findViewById(R.id.scrollView);

        MaterialButton btnAddPhotos = findViewById(R.id.btnAddPhotos);
        MaterialButton btnCamera = findViewById(R.id.btnCamera);
        MaterialButton btnSettings = findViewById(R.id.btnSettings);
        MaterialButton btnClearAll = findViewById(R.id.btnClearAll);

        btnAddPhotos.setOnClickListener(v -> checkPermissionsAndPick());
        btnCamera.setOnClickListener(v -> openCamera());
        btnSettings.setOnClickListener(v -> showSettingsDialog());
        btnClearAll.setOnClickListener(v -> clearAllPhotos());
        fabConvert.setOnClickListener(v -> {
            if (selectedPhotos.isEmpty()) Toast.makeText(this, "Önce fotoğraf ekleyin!", Toast.LENGTH_SHORT).show();
            else startConversion();
        });
    }

    private void setupRecyclerView() {
        photoAdapter = new PhotoAdapter(selectedPhotos, this::removePhoto);
        recyclerView.setAdapter(photoAdapter);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(
                ItemTouchHelper.UP | ItemTouchHelper.DOWN | ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT, 0) {
            @Override
            public boolean onMove(RecyclerView rv, RecyclerView.ViewHolder vh, RecyclerView.ViewHolder target) {
                int from = vh.getAdapterPosition();
                int to = target.getAdapterPosition();
                Collections.swap(selectedPhotos, from, to);
                photoAdapter.notifyItemMoved(from, to);
                return true;
            }
            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {}
        });
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    private void checkPermissionsAndPick() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                openPhotoPicker();
            } else {
                permissionLauncher.launch(new String[]{Manifest.permission.READ_MEDIA_IMAGES});
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                openPhotoPicker();
            } else {
                permissionLauncher.launch(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE});
            }
        }
    }

    private void openPhotoPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        photoPickerLauncher.launch(intent);
    }

    private void openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(new String[]{Manifest.permission.CAMERA});
            return;
        }
        Intent intent = new Intent(this, CameraActivity.class);
        cameraLauncher.launch(intent);
    }

    private void removePhoto(int position) {
        if (position >= 0 && position < selectedPhotos.size()) {
            selectedPhotos.remove(position);
            photoAdapter.notifyItemRemoved(position);
            photoAdapter.notifyItemRangeChanged(position, selectedPhotos.size());
            updateUI();
        }
    }

    private void clearAllPhotos() {
        if (!selectedPhotos.isEmpty()) {
            new MaterialAlertDialogBuilder(this)
                .setTitle("Tüm Fotoğrafları Temizle")
                .setMessage("Emin misiniz?")
                .setPositiveButton("Evet", (d, w) -> {
                    int size = selectedPhotos.size();
                    selectedPhotos.clear();
                    photoAdapter.notifyItemRangeRemoved(0, size);
                    updateUI();
                })
                .setNegativeButton("İptal", null)
                .show();
        }
    }

    private void showSettingsDialog() {
        View settingsView = getLayoutInflater().inflate(R.layout.dialog_settings, null);

        Slider qualitySlider = settingsView.findViewById(R.id.qualitySlider);
        TextView tvQualityValue = settingsView.findViewById(R.id.tvQualityValue);
        RadioGroup rgPageSize = settingsView.findViewById(R.id.rgPageSize);
        SwitchMaterial switchScanner = settingsView.findViewById(R.id.switchScanner);

        qualitySlider.setValue(pdfQuality);
        tvQualityValue.setText(pdfQuality + "%");
        switchScanner.setChecked(scannerMode);

        switch (pageSize) {
            case "A4": rgPageSize.check(R.id.rbA4); break;
            case "A3": rgPageSize.check(R.id.rbA3); break;
            case "Letter": rgPageSize.check(R.id.rbLetter); break;
            case "A5": rgPageSize.check(R.id.rbA5); break;
        }

        qualitySlider.addOnChangeListener((slider, value, fromUser) ->
            tvQualityValue.setText((int) value + "%"));

        new MaterialAlertDialogBuilder(this)
            .setTitle("PDF Ayarları")
            .setView(settingsView)
            .setPositiveButton("Kaydet", (d, w) -> {
                pdfQuality = (int) qualitySlider.getValue();
                scannerMode = switchScanner.isChecked();
                int selectedId = rgPageSize.getCheckedRadioButtonId();
                if (selectedId == R.id.rbA4) pageSize = "A4";
                else if (selectedId == R.id.rbA3) pageSize = "A3";
                else if (selectedId == R.id.rbLetter) pageSize = "Letter";
                else if (selectedId == R.id.rbA5) pageSize = "A5";
                String msg = "Kaydedildi: " + pageSize + ", Kalite: " + pdfQuality + "%" + (scannerMode ? ", Tarayıcı modu ✓" : "");
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("İptal", null)
            .show();
    }

    private void startConversion() {
        Intent intent = new Intent(this, ConvertActivity.class);
        intent.putParcelableArrayListExtra("photos", new ArrayList<>(selectedPhotos));
        intent.putExtra("quality", pdfQuality);
        intent.putExtra("pageSize", pageSize);
        intent.putExtra("scannerMode", scannerMode);
        startActivity(intent);
    }

    private void updateUI() {
        int count = selectedPhotos.size();
        tvPhotoCount.setText(count + " fotoğraf seçildi");
        if (count == 0) {
            tvEmptyState.setVisibility(View.VISIBLE);
            scrollView.setVisibility(View.GONE);
            fabConvert.hide();
        } else {
            tvEmptyState.setVisibility(View.GONE);
            scrollView.setVisibility(View.VISIBLE);
            fabConvert.show();
            fabConvert.setText("PDF Oluştur (" + count + ")");
            photoAdapter.notifyDataSetChanged();
        }
    }
}
