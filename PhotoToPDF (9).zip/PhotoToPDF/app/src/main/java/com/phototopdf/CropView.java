package com.phototopdf;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * Interactive crop view: shows image with 4 draggable corner handles.
 * User can drag corners to adjust document boundary.
 */
public class CropView extends View {

    private Bitmap bitmap;
    private float imgOffX, imgOffY, imgScale;

    // 4 corners in VIEW coordinates: TL, TR, BR, BL
    private float[] cx = new float[4];
    private float[] cy = new float[4];

    private int dragIndex = -1;
    private static final float HANDLE_RADIUS = 36f;
    private static final float TOUCH_RADIUS = 60f;

    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handleBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dimPaint = new Paint();

    public CropView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        fillPaint.setColor(Color.parseColor("#4000BCD4"));
        fillPaint.setStyle(Paint.Style.FILL);

        borderPaint.setColor(Color.parseColor("#00BCD4"));
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(4f);
        borderPaint.setStrokeJoin(Paint.Join.ROUND);

        handlePaint.setColor(Color.parseColor("#00BCD4"));
        handlePaint.setStyle(Paint.Style.FILL);

        handleBorderPaint.setColor(Color.WHITE);
        handleBorderPaint.setStyle(Paint.Style.STROKE);
        handleBorderPaint.setStrokeWidth(3f);

        dimPaint.setColor(Color.argb(140, 0, 0, 0));
        dimPaint.setStyle(Paint.Style.FILL);
    }

    public void setBitmap(Bitmap bmp, float[] corners) {
        this.bitmap = bmp;
        post(() -> {
            layoutImage();
            if (corners != null) {
                setCorners(corners);
            } else {
                setDefaultCorners();
            }
            invalidate();
        });
    }

    private void layoutImage() {
        if (bitmap == null) return;
        float vw = getWidth(), vh = getHeight();
        float bw = bitmap.getWidth(), bh = bitmap.getHeight();
        imgScale = Math.min(vw / bw, vh / bh);
        imgOffX = (vw - bw * imgScale) / 2f;
        imgOffY = (vh - bh * imgScale) / 2f;
    }

    /** corners: float[8] in IMAGE coords {x0,y0,x1,y1,x2,y2,x3,y3} TL,TR,BR,BL */
    private void setCorners(float[] corners) {
        for (int i = 0; i < 4; i++) {
            cx[i] = corners[i*2]   * imgScale + imgOffX;
            cy[i] = corners[i*2+1] * imgScale + imgOffY;
        }
    }

    private void setDefaultCorners() {
        if (bitmap == null) return;
        float margin = Math.min(getWidth(), getHeight()) * 0.08f;
        float l = imgOffX + margin, t = imgOffY + margin;
        float r = imgOffX + bitmap.getWidth()  * imgScale - margin;
        float b = imgOffY + bitmap.getHeight() * imgScale - margin;
        cx[0] = l; cy[0] = t; // TL
        cx[1] = r; cy[1] = t; // TR
        cx[2] = r; cy[2] = b; // BR
        cx[3] = l; cy[3] = b; // BL
    }

    /** Returns corners in IMAGE coordinates */
    public float[] getImageCorners() {
        float[] corners = new float[8];
        for (int i = 0; i < 4; i++) {
            corners[i*2]   = (cx[i] - imgOffX) / imgScale;
            corners[i*2+1] = (cy[i] - imgOffY) / imgScale;
        }
        return corners;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldW, int oldH) {
        super.onSizeChanged(w, h, oldW, oldH);
        if (bitmap != null) {
            layoutImage();
            setDefaultCorners();
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (bitmap == null) return;

        // Draw image
        Matrix m = new Matrix();
        m.setScale(imgScale, imgScale);
        m.postTranslate(imgOffX, imgOffY);
        canvas.drawBitmap(bitmap, m, new Paint(Paint.FILTER_BITMAP_FLAG));

        // Build quad path
        Path quad = new Path();
        quad.moveTo(cx[0], cy[0]);
        quad.lineTo(cx[1], cy[1]);
        quad.lineTo(cx[2], cy[2]);
        quad.lineTo(cx[3], cy[3]);
        quad.close();

        // Dim outside quad
        Path dim = new Path();
        dim.addRect(0, 0, getWidth(), getHeight(), Path.Direction.CW);
        dim.addPath(quad);
        canvas.save();
        canvas.clipOutPath(quad);
        canvas.drawRect(0, 0, getWidth(), getHeight(), dimPaint);
        canvas.restore();

        // Fill + border
        canvas.drawPath(quad, fillPaint);
        canvas.drawPath(quad, borderPaint);

        // Edge midpoint lines
        drawEdgeLine(canvas, 0, 1);
        drawEdgeLine(canvas, 1, 2);
        drawEdgeLine(canvas, 2, 3);
        drawEdgeLine(canvas, 3, 0);

        // Corner handles
        for (int i = 0; i < 4; i++) {
            canvas.drawCircle(cx[i], cy[i], HANDLE_RADIUS, handlePaint);
            canvas.drawCircle(cx[i], cy[i], HANDLE_RADIUS, handleBorderPaint);
        }
    }

    private void drawEdgeLine(Canvas canvas, int a, int b) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#00BCD4"));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        p.setPathEffect(new DashPathEffect(new float[]{12, 8}, 0));
        canvas.drawLine(cx[a], cy[a], cx[b], cy[b], p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float tx = event.getX(), ty = event.getY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                dragIndex = -1;
                float minDist = TOUCH_RADIUS;
                for (int i = 0; i < 4; i++) {
                    float d = (float)Math.sqrt(Math.pow(tx-cx[i],2)+Math.pow(ty-cy[i],2));
                    if (d < minDist) { minDist = d; dragIndex = i; }
                }
                return dragIndex >= 0;
            case MotionEvent.ACTION_MOVE:
                if (dragIndex >= 0) {
                    cx[dragIndex] = Math.max(0, Math.min(getWidth(),  tx));
                    cy[dragIndex] = Math.max(0, Math.min(getHeight(), ty));
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragIndex = -1;
                return true;
        }
        return super.onTouchEvent(event);
    }
}
