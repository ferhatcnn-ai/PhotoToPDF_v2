package com.phototopdf;

import android.graphics.*;

/**
 * Improved document corner detection.
 * Works on the full captured image (not live preview) for best accuracy.
 *
 * Strategy:
 * 1. Downscale to ~800px wide for speed
 * 2. Convert to grayscale + Gaussian blur
 * 3. Adaptive threshold (handles uneven lighting / shadows)
 * 4. Dilate edges slightly
 * 5. Find largest contour / bright rectangle
 * 6. Return 4 corners in original image coordinates
 */
public class DocumentDetector {

    private static final int WORK_WIDTH = 800;

    public static float[] detect(Bitmap src) {
        if (src == null) return null;

        int origW = src.getWidth(), origH = src.getHeight();

        // --- Downscale ---
        float scale = Math.min(1f, WORK_WIDTH / (float) origW);
        int W = (int)(origW * scale);
        int H = (int)(origH * scale);
        Bitmap small = Bitmap.createScaledBitmap(src, W, H, true);

        // --- Grayscale ---
        int[] pixels = new int[W * H];
        small.getPixels(pixels, 0, W, 0, 0, W, H);
        small.recycle();

        int[] gray = new int[W * H];
        for (int i = 0; i < pixels.length; i++) {
            int c = pixels[i];
            gray[i] = (77 * Color.red(c) + 150 * Color.green(c) + 29 * Color.blue(c)) >> 8;
        }

        // --- Gaussian blur 5x5 ---
        gray = blur(gray, W, H);

        // --- Adaptive threshold ---
        // For each pixel: compare to local mean in 15x15 window
        boolean[] mask = adaptiveThreshold(gray, W, H, 15, 10);

        // --- Dilate to connect broken edges ---
        mask = dilate(mask, W, H, 2);

        // --- Find document quad ---
        float[] quad = findLargestQuad(mask, gray, W, H);

        if (quad == null) return null;

        // Scale back to original image coords
        float invScale = 1f / scale;
        for (int i = 0; i < quad.length; i++) {
            quad[i] *= invScale;
        }

        // Clamp to image
        for (int i = 0; i < 4; i++) {
            quad[i*2]   = Math.max(0, Math.min(origW, quad[i*2]));
            quad[i*2+1] = Math.max(0, Math.min(origH, quad[i*2+1]));
        }

        // Validate: area must be > 15% and < 98% of image
        if (!isValidQuad(quad, origW, origH)) return null;

        return quad;
    }

    // ---- Gaussian blur 5x5 ----
    private static int[] blur(int[] gray, int W, int H) {
        int[] kernel = {1,4,7,4,1, 4,16,26,16,4, 7,26,41,26,7, 4,16,26,16,4, 1,4,7,4,1};
        int[] out = new int[W * H];
        for (int y = 2; y < H-2; y++) {
            for (int x = 2; x < W-2; x++) {
                int sum = 0, ki = 0;
                for (int ky = -2; ky <= 2; ky++)
                    for (int kx = -2; kx <= 2; kx++)
                        sum += gray[(y+ky)*W+(x+kx)] * kernel[ki++];
                out[y*W+x] = sum / 273;
            }
        }
        return out;
    }

    // ---- Adaptive threshold using integral image ----
    private static boolean[] adaptiveThreshold(int[] gray, int W, int H, int blockSize, int C) {
        // Build integral image
        long[] integral = new long[W * H];
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                long above = y > 0 ? integral[(y-1)*W+x] : 0;
                long left  = x > 0 ? integral[y*W+x-1] : 0;
                long aboveLeft = (y > 0 && x > 0) ? integral[(y-1)*W+x-1] : 0;
                integral[y*W+x] = gray[y*W+x] + above + left - aboveLeft;
            }
        }
        int half = blockSize / 2;
        boolean[] mask = new boolean[W * H];
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                int x1 = Math.max(0, x-half), y1 = Math.max(0, y-half);
                int x2 = Math.min(W-1, x+half), y2 = Math.min(H-1, y+half);
                int count = (x2-x1+1) * (y2-y1+1);
                long sum = integral[y2*W+x2]
                    - (x1 > 0 ? integral[y2*W+x1-1] : 0)
                    - (y1 > 0 ? integral[(y1-1)*W+x2] : 0)
                    + (x1 > 0 && y1 > 0 ? integral[(y1-1)*W+x1-1] : 0);
                int mean = (int)(sum / count);
                // Pixel is "document" if it's brighter than local mean (paper is bright)
                mask[y*W+x] = gray[y*W+x] >= (mean - C);
            }
        }
        return mask;
    }

    // ---- Dilate (expand bright regions) ----
    private static boolean[] dilate(boolean[] mask, int W, int H, int radius) {
        boolean[] out = new boolean[W * H];
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                boolean val = false;
                outer:
                for (int dy = -radius; dy <= radius; dy++) {
                    for (int dx = -radius; dx <= radius; dx++) {
                        int nx = x+dx, ny = y+dy;
                        if (nx>=0&&nx<W&&ny>=0&&ny<H&&mask[ny*W+nx]) { val=true; break outer; }
                    }
                }
                out[y*W+x] = val;
            }
        }
        return out;
    }

    /**
     * Find the largest bright rectangle in the mask.
     * Uses a "largest rectangle in histogram" inspired scan + boundary tracing.
     */
    private static float[] findLargestQuad(boolean[] mask, int[] gray, int W, int H) {
        int margin = (int)(Math.min(W,H) * 0.04f);

        // Scan from each edge to find document boundary more robustly
        // Use multiple scan lines and vote for each boundary

        int[] topVotes    = new int[H];
        int[] bottomVotes = new int[H];
        int[] leftVotes   = new int[W];
        int[] rightVotes  = new int[W];

        int step = 4;

        // Scan each column top-to-bottom and bottom-to-top
        for (int x = margin; x < W-margin; x += step) {
            // Find first bright pixel from top
            for (int y = margin; y < H/2; y++) {
                if (mask[y*W+x]) { topVotes[y]++; break; }
            }
            // Find first bright pixel from bottom
            for (int y = H-margin-1; y > H/2; y--) {
                if (mask[y*W+x]) { bottomVotes[y]++; break; }
            }
        }

        // Scan each row left-to-right and right-to-left
        for (int y = margin; y < H-margin; y += step) {
            for (int x = margin; x < W/2; x++) {
                if (mask[y*W+x]) { leftVotes[x]++; break; }
            }
            for (int x = W-margin-1; x > W/2; x--) {
                if (mask[y*W+x]) { rightVotes[x]++; break; }
            }
        }

        // Find peak in each direction
        int topY    = findPeak(topVotes,    margin, H/2)  ;
        int bottomY = findPeak(bottomVotes, H/2, H-margin);
        int leftX   = findPeak(leftVotes,   margin, W/2)  ;
        int rightX  = findPeak(rightVotes,  W/2, W-margin);

        if (topY < 0 || bottomY < 0 || leftX < 0 || rightX < 0) return null;

        // Ensure ordering
        if (topY >= bottomY || leftX >= rightX) return null;

        // Expand slightly to not cut edges
        int pad = (int)(Math.min(W,H) * 0.01f);
        topY    = Math.max(0, topY - pad);
        bottomY = Math.min(H-1, bottomY + pad);
        leftX   = Math.max(0, leftX - pad);
        rightX  = Math.min(W-1, rightX + pad);

        // Now refine corners: find the actual corners more precisely
        // by scanning near each corner region
        float tlX = leftX,  tlY = topY;
        float trX = rightX, trY = topY;
        float brX = rightX, brY = bottomY;
        float blX = leftX,  blY = bottomY;

        // Refine top-left corner
        float[] tl = refineCorner(mask, gray, leftX, topY, W, H, 1, 1);
        float[] tr = refineCorner(mask, gray, rightX, topY, W, H, -1, 1);
        float[] br = refineCorner(mask, gray, rightX, bottomY, W, H, -1, -1);
        float[] bl = refineCorner(mask, gray, leftX, bottomY, W, H, 1, -1);

        if (tl != null) { tlX = tl[0]; tlY = tl[1]; }
        if (tr != null) { trX = tr[0]; trY = tr[1]; }
        if (br != null) { brX = br[0]; brY = br[1]; }
        if (bl != null) { blX = bl[0]; blY = bl[1]; }

        return new float[]{tlX, tlY, trX, trY, brX, brY, blX, blY};
    }

    /** Find the index with most votes in a range */
    private static int findPeak(int[] votes, int from, int to) {
        // Smooth votes first
        int best = -1, bestVal = 0;
        for (int i = from; i < to; i++) {
            // Look at a small window around i
            int sum = 0;
            for (int d = -3; d <= 3; d++) {
                int idx = i+d;
                if (idx >= from && idx < to) sum += votes[idx];
            }
            if (sum > bestVal) { bestVal = sum; best = i; }
        }
        return bestVal > 0 ? best : -1;
    }

    /**
     * Refine a corner by searching in a small region.
     * dirX/dirY: direction toward interior (+1 or -1)
     */
    private static float[] refineCorner(boolean[] mask, int[] gray,
            int startX, int startY, int W, int H, int dirX, int dirY) {
        int searchR = (int)(Math.min(W,H) * 0.06f);
        float bestX = startX, bestY = startY;
        float bestScore = -1;

        for (int dy = 0; dy <= searchR; dy++) {
            for (int dx = 0; dx <= searchR; dx++) {
                int x = startX + dx * dirX;
                int y = startY + dy * dirY;
                if (x < 0 || x >= W || y < 0 || y >= H) continue;

                // Score = how much this point looks like a corner
                // (bright pixel with dark pixels on outer sides)
                if (!mask[y*W+x]) continue;

                int outerX = x - dirX, outerY = y - dirY;
                boolean outerXDark = (outerX >= 0 && outerX < W && !mask[y*W+outerX]);
                boolean outerYDark = (outerY >= 0 && outerY < H && !mask[outerY*W+x]);

                float score = 1f;
                if (outerXDark) score += 2f;
                if (outerYDark) score += 2f;

                // Prefer corners closer to original estimate
                float dist = (float)Math.sqrt(dx*dx + dy*dy);
                score -= dist * 0.05f;

                if (score > bestScore) { bestScore = score; bestX = x; bestY = y; }
            }
        }
        return new float[]{bestX, bestY};
    }

    private static boolean isValidQuad(float[] c, int W, int H) {
        float area = Math.abs(
            (c[0]*c[3]-c[2]*c[1]) + (c[2]*c[5]-c[4]*c[3]) +
            (c[4]*c[7]-c[6]*c[5]) + (c[6]*c[1]-c[0]*c[7])
        ) / 2f;
        float ratio = area / (W * H);
        return ratio > 0.12f && ratio < 0.98f;
    }

    /**
     * Perspective-correct crop using 4 corners.
     */
    public static Bitmap cropAndCorrect(Bitmap src, float[] corners) {
        if (corners == null || src == null) return src;

        float tlX=corners[0],tlY=corners[1],trX=corners[2],trY=corners[3];
        float brX=corners[4],brY=corners[5],blX=corners[6],blY=corners[7];

        float wTop  = dist(tlX,tlY,trX,trY);
        float wBot  = dist(blX,blY,brX,brY);
        float hLeft = dist(tlX,tlY,blX,blY);
        float hRight= dist(trX,trY,brX,brY);

        int outW = (int)Math.max(wTop, wBot);
        int outH = (int)Math.max(hLeft, hRight);
        if (outW <= 10 || outH <= 10) return src;

        float[] srcPts = {tlX,tlY, trX,trY, brX,brY, blX,blY};
        float[] dstPts = {0,0, outW,0, outW,outH, 0,outH};

        Matrix matrix = new Matrix();
        matrix.setPolyToPoly(srcPts, 0, dstPts, 0, 4);

        Bitmap result = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawColor(Color.WHITE);
        canvas.drawBitmap(src, matrix, new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG));
        return result;
    }

    private static float dist(float x1, float y1, float x2, float y2) {
        return (float)Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
    }
}
