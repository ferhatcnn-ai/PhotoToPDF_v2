package com.phototopdf;

import android.content.Intent;
import android.graphics.*;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import com.google.android.material.button.MaterialButton;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class CropActivity extends AppCompatActivity {

    private CropView cropView;
    private Bitmap originalBitmap;
    private String imagePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop);

        cropView = findViewById(R.id.cropView);
        MaterialButton btnConfirm = findViewById(R.id.btnCropConfirm);
        MaterialButton btnBack = findViewById(R.id.btnCropBack);
        MaterialButton btnReset = findViewById(R.id.btnReset);

        imagePath = getIntent().getStringExtra("imagePath");
        if (imagePath == null) { finish(); return; }

        loadImage();

        btnConfirm.setOnClickListener(v -> confirmCrop());
        btnBack.setOnClickListener(v -> finish());
        btnReset.setOnClickListener(v -> resetCorners());
    }

    private void loadImage() {
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = 1;
        originalBitmap = BitmapFactory.decodeFile(imagePath, opts);
        if (originalBitmap == null) { finish(); return; }

        originalBitmap = DocumentProcessor.correctOrientation(imagePath, originalBitmap);

        // Run detection in background (full image = slower but more accurate)
        TextView tvHint = findViewById(R.id.tvHint);
        tvHint.setText("⏳ Belge algılanıyor...");

        new Thread(() -> {
            float[] corners = DocumentDetector.detect(originalBitmap);
            runOnUiThread(() -> {
                if (corners != null) {
                    tvHint.setText("✅ Belge algılandı — köşeleri sürükleyerek düzeltin");
                    tvHint.setTextColor(android.graphics.Color.parseColor("#00BCD4"));
                } else {
                    tvHint.setText("⚠️ Otomatik algılanamadı — köşeleri manuel ayarlayın");
                    tvHint.setTextColor(android.graphics.Color.parseColor("#FF9800"));
                }
                cropView.setBitmap(originalBitmap, corners);
            });
        }).start();
    }

    private void resetCorners() {
        cropView.setBitmap(originalBitmap, null);
    }

    private void confirmCrop() {
        float[] corners = cropView.getImageCorners();

        // Apply perspective correction
        Bitmap cropped = DocumentDetector.cropAndCorrect(originalBitmap, corners);
        if (cropped == null) cropped = originalBitmap;

        try {
            File outDir = new File(getCacheDir(), "processed");
            if (!outDir.exists()) outDir.mkdirs();
            String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            File outFile = new File(outDir, "crop_" + ts + ".jpg");

            FileOutputStream fos = new FileOutputStream(outFile);
            cropped.compress(Bitmap.CompressFormat.JPEG, 95, fos);
            fos.close();

            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", outFile);
            Intent result = new Intent();
            result.setData(uri);
            result.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            setResult(RESULT_OK, result);
            finish();
        } catch (Exception e) {
            Toast.makeText(this, "Hata: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
