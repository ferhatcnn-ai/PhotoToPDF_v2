package com.phototopdf;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;

/**
 * Draws a real-time document detection overlay on the camera preview.
 * Shows either a detected document quad (teal polygon) or a static guide frame.
 */
public class DocumentOverlayView extends View {

    // Detected quad corners in view coordinates
    private float[] quadPoints = null; // [x0,y0, x1,y1, x2,y2, x3,y3] TL,TR,BR,BL
    private boolean documentDetected = false;

    private final Paint quadPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cornerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dimPaint = new Paint();
    private final Paint guidePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path dimPath = new Path();
    private final Path quadPath = new Path();

    public DocumentOverlayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        // Teal border like in the reference app
        quadPaint.setColor(Color.parseColor("#00BCD4"));
        quadPaint.setStyle(Paint.Style.STROKE);
        quadPaint.setStrokeWidth(5f);
        quadPaint.setStrokeJoin(Paint.Join.ROUND);

        // Translucent teal fill
        fillPaint.setColor(Color.parseColor("#3000BCD4"));
        fillPaint.setStyle(Paint.Style.FILL);

        // Corner dots
        cornerPaint.setColor(Color.parseColor("#00BCD4"));
        cornerPaint.setStyle(Paint.Style.FILL);

        // Dim overlay outside guide
        dimPaint.setColor(Color.argb(100, 0, 0, 0));
        dimPaint.setStyle(Paint.Style.FILL);

        // Static guide dashed border
        guidePaint.setColor(Color.argb(180, 255, 255, 255));
        guidePaint.setStyle(Paint.Style.STROKE);
        guidePaint.setStrokeWidth(2f);
        guidePaint.setPathEffect(new DashPathEffect(new float[]{20, 10}, 0));

        // Label
        labelPaint.setColor(Color.WHITE);
        labelPaint.setTextSize(36f);
        labelPaint.setTextAlign(Paint.Align.CENTER);
        labelPaint.setShadowLayer(4f, 0, 0, Color.BLACK);
    }

    /**
     * Call this from image analysis to update the detected quad.
     * corners: float[8] = {x0,y0, x1,y1, x2,y2, x3,y3} in VIEW coordinates, or null if not found.
     */
    public void setDetectedQuad(float[] corners) {
        this.quadPoints = corners;
        this.documentDetected = corners != null;
        postInvalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) return;

        if (documentDetected && quadPoints != null && quadPoints.length == 8) {
            drawDetectedDocument(canvas, w, h);
        } else {
            drawGuideFrame(canvas, w, h);
        }
    }

    private void drawDetectedDocument(Canvas canvas, int w, int h) {
        float x0 = quadPoints[0], y0 = quadPoints[1];
        float x1 = quadPoints[2], y1 = quadPoints[3];
        float x2 = quadPoints[4], y2 = quadPoints[5];
        float x3 = quadPoints[6], y3 = quadPoints[7];

        // Build quad path
        quadPath.reset();
        quadPath.moveTo(x0, y0);
        quadPath.lineTo(x1, y1);
        quadPath.lineTo(x2, y2);
        quadPath.lineTo(x3, y3);
        quadPath.close();

        // Dim everything outside
        dimPath.reset();
        dimPath.addRect(0, 0, w, h, Path.Direction.CW);
        dimPath.addPath(quadPath); // subtract quad from dim
        canvas.save();
        canvas.clipOutPath(quadPath);
        canvas.drawRect(0, 0, w, h, dimPaint);
        canvas.restore();

        // Fill inside
        canvas.drawPath(quadPath, fillPaint);
        // Border
        canvas.drawPath(quadPath, quadPaint);

        // Corner circles
        float r = 14f;
        canvas.drawCircle(x0, y0, r, cornerPaint);
        canvas.drawCircle(x1, y1, r, cornerPaint);
        canvas.drawCircle(x2, y2, r, cornerPaint);
        canvas.drawCircle(x3, y3, r, cornerPaint);

        // Label
        canvas.drawText("Belge algılandı ✓", w / 2f, y0 - 24f > 40f ? y0 - 24f : y2 + 60f, labelPaint);
    }

    private void drawGuideFrame(Canvas canvas, int w, int h) {
        float margin = w * 0.08f;
        float frameW = w - margin * 2;
        float frameH = frameW * 1.414f;
        float frameTop = (h - frameH) / 2f;
        if (frameTop < margin) {
            frameTop = margin;
            frameH = h - margin * 2;
            frameW = frameH / 1.414f;
            margin = (w - frameW) / 2f;
        }
        float frameBottom = frameTop + frameH;
        float frameLeft = margin;
        float frameRight = margin + frameW;

        // Dim outside
        dimPath.reset();
        dimPath.addRect(0, 0, w, h, Path.Direction.CW);
        dimPath.addRect(frameLeft, frameTop, frameRight, frameBottom, Path.Direction.CCW);
        canvas.drawPath(dimPath, dimPaint);

        // Dashed border
        canvas.drawRect(frameLeft, frameTop, frameRight, frameBottom, guidePaint);

        // Corner marks
        float cLen = 55f;
        Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG);
        cp.setColor(Color.WHITE);
        cp.setStyle(Paint.Style.STROKE);
        cp.setStrokeWidth(7f);
        cp.setStrokeCap(Paint.Cap.ROUND);

        canvas.drawLine(frameLeft, frameTop + cLen, frameLeft, frameTop, cp);
        canvas.drawLine(frameLeft, frameTop, frameLeft + cLen, frameTop, cp);
        canvas.drawLine(frameRight - cLen, frameTop, frameRight, frameTop, cp);
        canvas.drawLine(frameRight, frameTop, frameRight, frameTop + cLen, cp);
        canvas.drawLine(frameLeft, frameBottom - cLen, frameLeft, frameBottom, cp);
        canvas.drawLine(frameLeft, frameBottom, frameLeft + cLen, frameBottom, cp);
        canvas.drawLine(frameRight - cLen, frameBottom, frameRight, frameBottom, cp);
        canvas.drawLine(frameRight, frameBottom, frameRight, frameBottom - cLen, cp);

        // Hint label
        canvas.drawText("Belgeyi çerçeveye hizalayın", w / 2f, frameTop - 20f > 30f ? frameTop - 20f : 50f, labelPaint);
    }
}
