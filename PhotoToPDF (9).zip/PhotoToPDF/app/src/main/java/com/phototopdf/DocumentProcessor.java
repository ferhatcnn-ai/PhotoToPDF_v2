package com.phototopdf;

import android.graphics.*;
import android.media.ExifInterface;

import java.io.IOException;

/**
 * Handles document edge detection, perspective correction, and image enhancement.
 * Uses pure Android/Java - no OpenCV needed.
 */
public class DocumentProcessor {

    /**
     * Detect document in image, crop and perspective-correct it.
     * Falls back to the original image if detection fails.
     */
    public static Bitmap detectAndCropDocument(Bitmap src) {
        if (src == null) return null;

        int w = src.getWidth();
        int h = src.getHeight();

        // Convert to grayscale for edge detection
        Bitmap gray = toGrayscale(src);

        // Find document corners using edge-based approach
        int[][] corners = findDocumentCorners(gray, w, h);

        if (corners != null && isValidQuad(corners, w, h)) {
            // Apply perspective transform
            return perspectiveTransform(src, corners);
        } else {
            // No document found, return original
            return src;
        }
    }

    /**
     * Convert to grayscale
     */
    private static Bitmap toGrayscale(Bitmap src) {
        Bitmap result = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        Paint paint = new Paint();
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0);
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(src, 0, 0, paint);
        return result;
    }

    /**
     * Find document corners by scanning for the largest bright rectangle
     */
    private static int[][] findDocumentCorners(Bitmap gray, int w, int h) {
        // Sample pixels at reduced resolution for performance
        int step = Math.max(1, Math.min(w, h) / 200);
        int[] pixels = new int[w * h];
        gray.getPixels(pixels, 0, w, 0, 0, w, h);

        // Find bounding box of document (bright region on possibly dark background)
        // Use edge detection: look for high contrast transitions
        int margin = (int)(Math.min(w, h) * 0.05f);

        // Simple approach: find the convex hull of bright pixels
        // Scan each border direction
        int topY = margin, bottomY = h - margin, leftX = margin, rightX = w - margin;

        // Scan from top
        outer:
        for (int y = margin; y < h / 2; y += step) {
            for (int x = margin; x < w - margin; x += step) {
                int px = pixels[y * w + x];
                int brightness = (Color.red(px) + Color.green(px) + Color.blue(px)) / 3;
                if (brightness > 180) {
                    topY = Math.max(margin, y - step * 2);
                    break outer;
                }
            }
        }

        // Scan from bottom
        outer:
        for (int y = h - margin; y > h / 2; y -= step) {
            for (int x = margin; x < w - margin; x += step) {
                int px = pixels[y * w + x];
                int brightness = (Color.red(px) + Color.green(px) + Color.blue(px)) / 3;
                if (brightness > 180) {
                    bottomY = Math.min(h - margin, y + step * 2);
                    break outer;
                }
            }
        }

        // Scan from left
        outer:
        for (int x = margin; x < w / 2; x += step) {
            for (int y = margin; y < h - margin; y += step) {
                int px = pixels[y * w + x];
                int brightness = (Color.red(px) + Color.green(px) + Color.blue(px)) / 3;
                if (brightness > 180) {
                    leftX = Math.max(margin, x - step * 2);
                    break outer;
                }
            }
        }

        // Scan from right
        outer:
        for (int x = w - margin; x > w / 2; x -= step) {
            for (int y = margin; y < h - margin; y += step) {
                int px = pixels[y * w + x];
                int brightness = (Color.red(px) + Color.green(px) + Color.blue(px)) / 3;
                if (brightness > 180) {
                    rightX = Math.min(w - margin, x + step * 2);
                    break outer;
                }
            }
        }

        // Return corners: TL, TR, BR, BL
        return new int[][]{
            {leftX, topY},
            {rightX, topY},
            {rightX, bottomY},
            {leftX, bottomY}
        };
    }

    /**
     * Check if detected quad is large enough and valid
     */
    private static boolean isValidQuad(int[][] corners, int w, int h) {
        int minArea = (int)(w * h * 0.2f); // at least 20% of image
        int quadW = corners[1][0] - corners[0][0];
        int quadH = corners[2][1] - corners[0][1];
        return quadW > 0 && quadH > 0 && (quadW * quadH) > minArea;
    }

    /**
     * Crop image to detected corners
     */
    private static Bitmap perspectiveTransform(Bitmap src, int[][] corners) {
        int left   = corners[0][0];
        int top    = corners[0][1];
        int right  = corners[1][0];
        int bottom = corners[2][1];

        int cropW = right - left;
        int cropH = bottom - top;

        if (cropW <= 0 || cropH <= 0) return src;

        return Bitmap.createBitmap(src, left, top, cropW, cropH);
    }

    /**
     * Apply scanner effect: grayscale + contrast boost + slight sharpen
     */
    public static Bitmap applyScanner(Bitmap src) {
        if (src == null) return null;
        Bitmap result = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);

        Paint paint = new Paint();

        // Grayscale + contrast boost
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0); // grayscale

        // Boost contrast: scale * pixel + translate
        float contrast = 1.4f;
        float brightness = -40f;
        ColorMatrix contrast_cm = new ColorMatrix(new float[]{
            contrast, 0, 0, 0, brightness,
            0, contrast, 0, 0, brightness,
            0, 0, contrast, 0, brightness,
            0, 0, 0, 1, 0
        });
        cm.postConcat(contrast_cm);

        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(src, 0, 0, paint);
        return result;
    }

    /**
     * Fix EXIF orientation including mirror/flip cases
     */
    public static Bitmap correctOrientation(String filePath, Bitmap bitmap) {
        try {
            ExifInterface exif = new ExifInterface(filePath);
            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL);
            Matrix matrix = new Matrix();
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    matrix.postRotate(90); break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    matrix.postRotate(180); break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    matrix.postRotate(270); break;
                case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:
                    matrix.postScale(-1, 1); break;
                case ExifInterface.ORIENTATION_FLIP_VERTICAL:
                    matrix.postScale(1, -1); break;
                case ExifInterface.ORIENTATION_TRANSPOSE:
                    matrix.postRotate(90); matrix.postScale(-1, 1); break;
                case ExifInterface.ORIENTATION_TRANSVERSE:
                    matrix.postRotate(-90); matrix.postScale(-1, 1); break;
                case ExifInterface.ORIENTATION_NORMAL:
                default:
                    return bitmap;
            }
            Bitmap result = Bitmap.createBitmap(bitmap, 0, 0,
                bitmap.getWidth(), bitmap.getHeight(), matrix, true);
            if (result != bitmap) bitmap.recycle();
            return result;
        } catch (IOException e) {
            return bitmap;
        }
    }
}
