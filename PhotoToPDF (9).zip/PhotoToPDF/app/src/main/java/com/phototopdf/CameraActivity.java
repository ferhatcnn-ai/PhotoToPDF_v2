package com.phototopdf;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.activity.result.*;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.exifinterface.media.ExifInterface;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.button.MaterialButton;
import com.google.common.util.concurrent.ListenableFuture;

import java.io.*;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class CameraActivity extends AppCompatActivity {

    private PreviewView previewView;
    private DocumentOverlayView overlayView;
    private FloatingActionButton btnCapture;
    private MaterialButton btnFlash;

    private ImageCapture imageCapture;
    private boolean flashEnabled = false;
    private File capturedFile;

    private long lastAnalysisTime = 0;
    private static final long ANALYSIS_INTERVAL_MS = 500;

    private final ExecutorService cameraExecutor = Executors.newSingleThreadExecutor();

    private final ActivityResultLauncher<String> permissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) startCamera();
            else { Toast.makeText(this, "Kamera izni gerekli!", Toast.LENGTH_LONG).show(); finish(); }
        });

    // CropActivity result
    private final ActivityResultLauncher<Intent> cropLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                // Pass the cropped image URI back to MainActivity
                setResult(RESULT_OK, result.getData());
                finish();
            }
            // If cancelled, stay on camera
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        previewView = findViewById(R.id.previewView);
        overlayView = findViewById(R.id.overlayView);
        btnCapture  = findViewById(R.id.btnCapture);
        btnFlash    = findViewById(R.id.btnFlash);

        // Hide the preview layout - we go directly to CropActivity
        View layoutPreview = findViewById(R.id.layoutPreview);
        if (layoutPreview != null) layoutPreview.setVisibility(View.GONE);

        btnCapture.setOnClickListener(v -> takePhoto());
        btnFlash.setOnClickListener(v -> toggleFlash());
        findViewById(R.id.btnClose).setOnClickListener(v -> finish());

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA);
        }
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = future.get();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                ImageCapture imageCapture2 = new ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .build();
                imageCapture = imageCapture2;

                CameraSelector selector = CameraSelector.DEFAULT_BACK_CAMERA;
                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, selector, preview, imageCapture);

            } catch (Exception e) {
                runOnUiThread(() ->
                    Toast.makeText(this, "Kamera hatası: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void analyzeFrame(ImageProxy imageProxy) {
        long now = System.currentTimeMillis();
        if (now - lastAnalysisTime < ANALYSIS_INTERVAL_MS) { imageProxy.close(); return; }
        lastAnalysisTime = now;
        try {
            Bitmap bitmap = imageProxyToBitmap(imageProxy);
            imageProxy.close();
            if (bitmap == null) return;

            int targetW = 400;
            int targetH = (int)(bitmap.getHeight() * (targetW / (float)bitmap.getWidth()));
            Bitmap scaled = Bitmap.createScaledBitmap(bitmap, targetW, targetH, false);
            bitmap.recycle();

            int imgW = scaled.getWidth(), imgH = scaled.getHeight();
            int viewW = previewView.getWidth(), viewH = previewView.getHeight();
            if (viewW == 0 || viewH == 0) { scaled.recycle(); return; }

            float[] corners = DocumentDetector.detect(scaled);
            scaled.recycle();

            if (corners != null) {
                float sx = (float)viewW / imgW, sy = (float)viewH / imgH;
                float[] vc = {
                    corners[0]*sx, corners[1]*sy,
                    corners[2]*sx, corners[3]*sy,
                    corners[4]*sx, corners[5]*sy,
                    corners[6]*sx, corners[7]*sy
                };
                runOnUiThread(() -> overlayView.setDetectedQuad(vc));
            } else {
                runOnUiThread(() -> overlayView.setDetectedQuad(null));
            }
        } catch (Exception e) {
            try { imageProxy.close(); } catch (Exception ignored) {}
        }
    }

    private void takePhoto() {
        if (imageCapture == null) return;
        try {
            File photoDir = new File(getCacheDir(), "photos");
            if (!photoDir.exists()) photoDir.mkdirs();
            String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            capturedFile = new File(photoDir, "IMG_" + ts + ".jpg");

            ImageCapture.OutputFileOptions opts =
                new ImageCapture.OutputFileOptions.Builder(capturedFile).build();
            btnCapture.setEnabled(false);

            imageCapture.takePicture(opts, cameraExecutor,
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(@NonNull ImageCapture.OutputFileResults r) {
                        runOnUiThread(() -> openCropScreen());
                    }
                    @Override
                    public void onError(@NonNull ImageCaptureException e) {
                        runOnUiThread(() -> {
                            btnCapture.setEnabled(true);
                            Toast.makeText(CameraActivity.this, "Hata: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        });
                    }
                });
        } catch (Exception e) {
            Toast.makeText(this, "Hata: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void openCropScreen() {
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = 1;
        Bitmap raw = BitmapFactory.decodeFile(capturedFile.getAbsolutePath(), opts);
        if (raw == null) { btnCapture.setEnabled(true); return; }

        // Fix orientation AND mirror issues from EXIF
        Bitmap fixed = DocumentProcessor.correctOrientation(capturedFile.getAbsolutePath(), raw);

        // Save corrected image back to file
        try {
            FileOutputStream fos = new FileOutputStream(capturedFile);
            fixed.compress(Bitmap.CompressFormat.JPEG, 95, fos);
            fos.close();
            // Clear EXIF orientation tag so it won't be applied twice
            ExifInterface exif = new ExifInterface(capturedFile.getAbsolutePath());
            exif.setAttribute(ExifInterface.TAG_ORIENTATION,
                String.valueOf(ExifInterface.ORIENTATION_NORMAL));
            exif.saveAttributes();
        } catch (Exception ignored) {}

        Intent intent = new Intent(this, CropActivity.class);
        intent.putExtra("imagePath", capturedFile.getAbsolutePath());
        cropLauncher.launch(intent);
    }

    private void toggleFlash() {
        flashEnabled = !flashEnabled;
        if (imageCapture != null)
            imageCapture.setFlashMode(flashEnabled ? ImageCapture.FLASH_MODE_ON : ImageCapture.FLASH_MODE_OFF);
        btnFlash.setText(flashEnabled ? "⚡ Açık" : "⚡ Flash");
    }

    private Bitmap imageProxyToBitmap(ImageProxy image) {
        try {
            ImageProxy.PlaneProxy[] planes = image.getPlanes();
            ByteBuffer yBuf = planes[0].getBuffer();
            ByteBuffer uBuf = planes[1].getBuffer();
            ByteBuffer vBuf = planes[2].getBuffer();
            byte[] nv21 = new byte[yBuf.remaining() + uBuf.remaining() + vBuf.remaining()];
            int ys = yBuf.remaining(), vs = vBuf.remaining();
            yBuf.get(nv21, 0, ys);
            vBuf.get(nv21, ys, vs);
            uBuf.get(nv21, ys + vs, uBuf.remaining());
            android.graphics.YuvImage yuv = new android.graphics.YuvImage(
                nv21, android.graphics.ImageFormat.NV21, image.getWidth(), image.getHeight(), null);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            yuv.compressToJpeg(new Rect(0, 0, image.getWidth(), image.getHeight()), 60, out);
            byte[] bytes = out.toByteArray();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 2;
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o);
        } catch (Exception e) { return null; }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cameraExecutor.shutdown();
    }
}
