# 📄 Photo to PDF — Android Uygulaması

Fotoğraflarınızı kolayca PDF'e dönüştürün!

## Özellikler
- ✅ Birden fazla fotoğraf seçme
- ✅ Sürükle-bırak ile fotoğraf sıralama
- ✅ PDF kalite ayarı (%20 - %100)
- ✅ Sayfa boyutu seçimi (A4, A3, Letter, A5)
- ✅ PDF paylaşma ve açma
- ✅ Android 7.0+ (API 24+) desteği

---

## 🔨 APK Nasıl Oluşturulur?

### Gereksinimler
- [Android Studio](https://developer.android.com/studio) (Hedgehog veya üstü)
- JDK 17+
- Android SDK (API 34)

### Adımlar

1. **Projeyi açın**
   - Android Studio'yu açın
   - `File → Open` → Bu klasörü (`PhotoToPDF`) seçin
   - Gradle sync tamamlanmasını bekleyin

2. **APK derleyin**
   - Menüden: `Build → Build Bundle(s) / APK(s) → Build APK(s)`
   - Ya da terminalde:
     ```
     ./gradlew assembleDebug
     ```

3. **APK konumu**
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

4. **Telefona yükleyin**
   - APK dosyasını telefonunuza kopyalayın
   - Dosya yöneticisinden açın
   - "Bilinmeyen kaynaklardan yüklemeye izin ver" seçeneğini etkinleştirin
   - Yükleyin!

---

## 📁 Proje Yapısı

```
PhotoToPDF/
├── app/
│   ├── src/main/
│   │   ├── java/com/phototopdf/
│   │   │   ├── MainActivity.java       # Ana ekran
│   │   │   ├── ConvertActivity.java    # PDF dönüşüm ekranı
│   │   │   └── PhotoAdapter.java      # Fotoğraf grid adaptörü
│   │   ├── res/
│   │   │   ├── layout/                # XML arayüz dosyaları
│   │   │   ├── values/                # Renkler, metinler, temalar
│   │   │   └── drawable/              # Görsel kaynaklar
│   │   └── AndroidManifest.xml
│   └── build.gradle
└── build.gradle
```

---

## 🛠 Kullanılan Kütüphaneler

| Kütüphane | Amaç |
|-----------|------|
| iText7 | PDF oluşturma |
| Glide | Fotoğraf yükleme |
| Material Components | Modern UI |
| RecyclerView | Fotoğraf listesi |

---

## 📱 Kullanım

1. **"+ Fotoğraf Ekle"** butonuna tıklayın
2. Galericiden birden fazla fotoğraf seçin
3. Fotoğrafları sürükleyerek sıralayın
4. **"⚙ Ayarlar"** ile kalite ve sayfa boyutu belirleyin
5. **"PDF Oluştur"** butonuna tıklayın
6. PDF hazır! Paylaşın veya açın.

PDF dosyaları **Belgeler/PhotoToPDF/** klasörüne kaydedilir.
